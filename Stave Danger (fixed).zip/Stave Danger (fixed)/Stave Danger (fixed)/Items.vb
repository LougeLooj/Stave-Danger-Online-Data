﻿Public Class Items

    Property DubPicbox As PictureBox
    Property UkePicbox As PictureBox
    Property LPPicbox
    Property Dub As Boolean
    Property Uke As Boolean
    Property LP As Boolean


End Class
