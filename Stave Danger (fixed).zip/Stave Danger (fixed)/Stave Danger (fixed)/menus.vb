﻿Public Class menus
    Dim controlparent As GameForm

    Public Sub New(ByVal tempParent As GameForm)


        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        controlparent = tempParent

    End Sub

    Private Sub Startlabel_Click(sender As Object, e As EventArgs) Handles Startlabel.Click
        controlparent.Startgame()

    End Sub


End Class
