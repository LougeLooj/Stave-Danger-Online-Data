﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GameForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BombTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Firerateup = New System.Windows.Forms.Timer(Me.components)
        Me.Firerateright = New System.Windows.Forms.Timer(Me.components)
        Me.Firerateleft = New System.Windows.Forms.Timer(Me.components)
        Me.Fireratedown = New System.Windows.Forms.Timer(Me.components)
        Me.Timeup = New System.Windows.Forms.Timer(Me.components)
        Me.Timeright = New System.Windows.Forms.Timer(Me.components)
        Me.Timeleft = New System.Windows.Forms.Timer(Me.components)
        Me.Timedown = New System.Windows.Forms.Timer(Me.components)
        Me.Explodetimer = New System.Windows.Forms.Timer(Me.components)
        Me.Shootup = New System.Windows.Forms.Timer(Me.components)
        Me.WalAI2 = New System.Windows.Forms.Timer(Me.components)
        Me.Itemtrackertmr = New System.Windows.Forms.Timer(Me.components)
        Me.WaluigiAI = New System.Windows.Forms.Timer(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ProgTmr = New System.Windows.Forms.Timer(Me.components)
        Me.Timer17 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer18 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer19 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer20 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer21 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer22 = New System.Windows.Forms.Timer(Me.components)
        Me.checktmr = New System.Windows.Forms.Timer(Me.components)
        Me.shootleft = New System.Windows.Forms.Timer(Me.components)
        Me.shootdown = New System.Windows.Forms.Timer(Me.components)
        Me.shootright = New System.Windows.Forms.Timer(Me.components)
        Me.Collisiondet = New System.Windows.Forms.Timer(Me.components)
        Me.Bombcounter = New System.Windows.Forms.Label()
        Me.Coincounter = New System.Windows.Forms.Label()
        Me.Healthbar = New System.Windows.Forms.PictureBox()
        Me.Playercontrolpicbox = New System.Windows.Forms.PictureBox()
        Me.Shoptalkbox = New System.Windows.Forms.PictureBox()
        Me.currentitem = New System.Windows.Forms.PictureBox()
        Me.DebugBox = New System.Windows.Forms.GroupBox()
        Me.dubcheck = New System.Windows.Forms.Label()
        Me.ukecheck = New System.Windows.Forms.Label()
        Me.GunPickupCooldownTmr = New System.Windows.Forms.Timer(Me.components)
        Me.ItemNamelbl = New System.Windows.Forms.Label()
        Me.ItemDescriptionlbl = New System.Windows.Forms.Label()
        Me.Nametagtmr = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.Healthbar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Playercontrolpicbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Shoptalkbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.currentitem, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DebugBox.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BombTimer
        '
        Me.BombTimer.Interval = 2000
        '
        'Firerateup
        '
        '
        'Firerateright
        '
        '
        'Firerateleft
        '
        '
        'Fireratedown
        '
        '
        'Timeup
        '
        Me.Timeup.Interval = 1
        '
        'Timeright
        '
        Me.Timeright.Interval = 1
        '
        'Timeleft
        '
        Me.Timeleft.Interval = 1
        '
        'Timedown
        '
        Me.Timedown.Interval = 1
        '
        'Explodetimer
        '
        Me.Explodetimer.Interval = 1000
        '
        'Shootup
        '
        Me.Shootup.Enabled = True
        Me.Shootup.Interval = 1
        '
        'WalAI2
        '
        Me.WalAI2.Enabled = True
        Me.WalAI2.Interval = 1
        '
        'Itemtrackertmr
        '
        Me.Itemtrackertmr.Interval = 1
        '
        'WaluigiAI
        '
        Me.WaluigiAI.Enabled = True
        Me.WaluigiAI.Interval = 1
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 500
        '
        'ProgTmr
        '
        Me.ProgTmr.Enabled = True
        Me.ProgTmr.Interval = 1
        '
        'checktmr
        '
        Me.checktmr.Enabled = True
        Me.checktmr.Interval = 1
        '
        'shootleft
        '
        Me.shootleft.Enabled = True
        Me.shootleft.Interval = 1
        '
        'shootdown
        '
        Me.shootdown.Enabled = True
        Me.shootdown.Interval = 1
        '
        'shootright
        '
        Me.shootright.Enabled = True
        Me.shootright.Interval = 1
        '
        'Collisiondet
        '
        Me.Collisiondet.Enabled = True
        Me.Collisiondet.Interval = 1
        '
        'Bombcounter
        '
        Me.Bombcounter.AutoSize = True
        Me.Bombcounter.Location = New System.Drawing.Point(0, 32)
        Me.Bombcounter.Name = "Bombcounter"
        Me.Bombcounter.Size = New System.Drawing.Size(51, 13)
        Me.Bombcounter.TabIndex = 1
        Me.Bombcounter.Text = "Bombs: 0"
        '
        'Coincounter
        '
        Me.Coincounter.AutoSize = True
        Me.Coincounter.Location = New System.Drawing.Point(0, 46)
        Me.Coincounter.Name = "Coincounter"
        Me.Coincounter.Size = New System.Drawing.Size(45, 13)
        Me.Coincounter.TabIndex = 2
        Me.Coincounter.Text = "Coins: 0"
        '
        'Healthbar
        '
        Me.Healthbar.BackColor = System.Drawing.Color.Chartreuse
        Me.Healthbar.Location = New System.Drawing.Point(3, 10)
        Me.Healthbar.Name = "Healthbar"
        Me.Healthbar.Size = New System.Drawing.Size(100, 19)
        Me.Healthbar.TabIndex = 3
        Me.Healthbar.TabStop = False
        '
        'Playercontrolpicbox
        '
        Me.Playercontrolpicbox.BackColor = System.Drawing.Color.Transparent
        Me.Playercontrolpicbox.Image = Global.Stave_Danger__fixed_.My.Resources.Resources.Untitled_2
        Me.Playercontrolpicbox.Location = New System.Drawing.Point(354, 312)
        Me.Playercontrolpicbox.Name = "Playercontrolpicbox"
        Me.Playercontrolpicbox.Size = New System.Drawing.Size(93, 113)
        Me.Playercontrolpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Playercontrolpicbox.TabIndex = 8
        Me.Playercontrolpicbox.TabStop = False
        '
        'Shoptalkbox
        '
        Me.Shoptalkbox.BackColor = System.Drawing.Color.White
        Me.Shoptalkbox.Image = Global.Stave_Danger__fixed_.My.Resources.Resources.Talkbox
        Me.Shoptalkbox.Location = New System.Drawing.Point(456, -138)
        Me.Shoptalkbox.Name = "Shoptalkbox"
        Me.Shoptalkbox.Size = New System.Drawing.Size(111, 57)
        Me.Shoptalkbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Shoptalkbox.TabIndex = 7
        Me.Shoptalkbox.TabStop = False
        '
        'currentitem
        '
        Me.currentitem.BackColor = System.Drawing.Color.Transparent
        Me.currentitem.Location = New System.Drawing.Point(643, 112)
        Me.currentitem.Name = "currentitem"
        Me.currentitem.Size = New System.Drawing.Size(100, 92)
        Me.currentitem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.currentitem.TabIndex = 4
        Me.currentitem.TabStop = False
        '
        'DebugBox
        '
        Me.DebugBox.BackColor = System.Drawing.Color.Transparent
        Me.DebugBox.Controls.Add(Me.dubcheck)
        Me.DebugBox.Controls.Add(Me.ukecheck)
        Me.DebugBox.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DebugBox.Location = New System.Drawing.Point(846, 109)
        Me.DebugBox.Name = "DebugBox"
        Me.DebugBox.Size = New System.Drawing.Size(164, 277)
        Me.DebugBox.TabIndex = 10
        Me.DebugBox.TabStop = False
        Me.DebugBox.Text = "Debug menu"
        '
        'dubcheck
        '
        Me.dubcheck.AutoSize = True
        Me.dubcheck.Location = New System.Drawing.Point(6, 53)
        Me.dubcheck.Name = "dubcheck"
        Me.dubcheck.Size = New System.Drawing.Size(56, 14)
        Me.dubcheck.TabIndex = 1
        Me.dubcheck.Text = "ItemDub:"
        '
        'ukecheck
        '
        Me.ukecheck.AutoSize = True
        Me.ukecheck.Location = New System.Drawing.Point(6, 27)
        Me.ukecheck.Name = "ukecheck"
        Me.ukecheck.Size = New System.Drawing.Size(56, 14)
        Me.ukecheck.TabIndex = 0
        Me.ukecheck.Text = "ItemUke:"
        '
        'GunPickupCooldownTmr
        '
        Me.GunPickupCooldownTmr.Interval = 2000
        '
        'ItemNamelbl
        '
        Me.ItemNamelbl.BackColor = System.Drawing.Color.Transparent
        Me.ItemNamelbl.Font = New System.Drawing.Font("Magneto", 50.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemNamelbl.Location = New System.Drawing.Point(-5, 0)
        Me.ItemNamelbl.Name = "ItemNamelbl"
        Me.ItemNamelbl.Size = New System.Drawing.Size(845, 73)
        Me.ItemNamelbl.TabIndex = 11
        Me.ItemNamelbl.Text = "Label1"
        Me.ItemNamelbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ItemNamelbl.Visible = False
        '
        'ItemDescriptionlbl
        '
        Me.ItemDescriptionlbl.BackColor = System.Drawing.Color.Transparent
        Me.ItemDescriptionlbl.Font = New System.Drawing.Font("Magneto", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemDescriptionlbl.Location = New System.Drawing.Point(3, 73)
        Me.ItemDescriptionlbl.Name = "ItemDescriptionlbl"
        Me.ItemDescriptionlbl.Size = New System.Drawing.Size(837, 36)
        Me.ItemDescriptionlbl.TabIndex = 12
        Me.ItemDescriptionlbl.Text = "Label2"
        Me.ItemDescriptionlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ItemDescriptionlbl.Visible = False
        '
        'Nametagtmr
        '
        Me.Nametagtmr.Interval = 1500
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Gold
        Me.PictureBox1.Location = New System.Drawing.Point(635, 104)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(116, 109)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 13
        Me.PictureBox1.TabStop = False
        '
        'GameForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(784, 761)
        Me.Controls.Add(Me.Healthbar)
        Me.Controls.Add(Me.Bombcounter)
        Me.Controls.Add(Me.Coincounter)
        Me.Controls.Add(Me.currentitem)
        Me.Controls.Add(Me.DebugBox)
        Me.Controls.Add(Me.Shoptalkbox)
        Me.Controls.Add(Me.Playercontrolpicbox)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ItemNamelbl)
        Me.Controls.Add(Me.ItemDescriptionlbl)
        Me.Name = "GameForm"
        Me.Text = "Stave Danger"
        CType(Me.Healthbar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Playercontrolpicbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Shoptalkbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.currentitem, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DebugBox.ResumeLayout(False)
        Me.DebugBox.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BombTimer As Timer
    Friend WithEvents Firerateup As Timer
    Friend WithEvents Firerateright As Timer
    Friend WithEvents Firerateleft As Timer
    Friend WithEvents Fireratedown As Timer
    Friend WithEvents Timeup As Timer
    Friend WithEvents Timeright As Timer
    Friend WithEvents Timeleft As Timer
    Friend WithEvents Timedown As Timer
    Friend WithEvents Explodetimer As Timer
    Friend WithEvents Shootup As Timer
    Friend WithEvents WalAI2 As Timer
    Friend WithEvents Itemtrackertmr As Timer
    Friend WithEvents WaluigiAI As Timer
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ProgTmr As Timer
    Friend WithEvents Timer17 As Timer
    Friend WithEvents Timer18 As Timer
    Friend WithEvents Timer19 As Timer
    Friend WithEvents Timer20 As Timer
    Friend WithEvents Timer21 As Timer
    Friend WithEvents Timer22 As Timer
    Friend WithEvents checktmr As Timer
    Friend WithEvents shootleft As Timer
    Friend WithEvents shootdown As Timer
    Friend WithEvents shootright As Timer
    Friend WithEvents Collisiondet As Timer
    Friend WithEvents Bombcounter As Label
    Friend WithEvents Coincounter As Label
    Friend WithEvents Healthbar As PictureBox
    Friend WithEvents currentitem As PictureBox
    Friend WithEvents Shoptalkbox As PictureBox
    Friend WithEvents Playercontrolpicbox As PictureBox
    Friend WithEvents DebugBox As GroupBox
    Friend WithEvents dubcheck As Label
    Friend WithEvents ukecheck As Label
    Friend WithEvents GunPickupCooldownTmr As Timer
    Friend WithEvents ItemNamelbl As Label
    Friend WithEvents ItemDescriptionlbl As Label
    Friend WithEvents Nametagtmr As Timer
    Friend WithEvents PictureBox1 As PictureBox
End Class
