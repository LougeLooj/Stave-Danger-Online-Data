﻿Public Class weakenemy

    Property weakenemyhp As Integer = 100
    Property healthbar As PictureBox
    Property picbox As PictureBox
    Property alive As Boolean
    Property speed As Integer = 2



End Class
