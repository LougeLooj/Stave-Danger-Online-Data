﻿Public Class Playercharacter
    Private currenthealth As Integer = 100
    Property sprite As Bitmap
    Property choice As Integer
    Property MaxHealth As Integer = 100


    Public Property Luigihp() As Integer

        Get
            Return currenthealth
        End Get
        Set(value As Integer)
            currenthealth = value

        End Set
    End Property
End Class
