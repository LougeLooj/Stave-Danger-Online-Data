﻿Public Class shop


    Private Sub shop_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub shop_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        GameForm.Show()
    End Sub

    Private Sub shop_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class