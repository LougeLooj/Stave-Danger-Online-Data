﻿Imports System.ComponentModel

Public Class GameForm


    'game variables
    Dim levelnumber As Integer
    'Controls how fast the player can shoot
    Dim firerate As Integer = 300
    Dim ExtraFirerate As Integer = 0
    'How much damage a bullet does
    Dim damage As Integer = 50
    Dim ExtraDamage As Integer = 0
    'how much damage a bomb does
    Dim bombdamage As Integer = damage * 3
    'how fast a player can move
    Dim playerspeed As Integer = 5
    'how fast a bullet can move
    Dim shotspeed As Integer = 10
    'test variable for collision
    Dim collision As Boolean = False
    'how many bombs the player has
    Dim bombs As Integer = 1
    'how many coins a player has 
    Dim coins As Integer = 5
    'object of the playercharacter class
    Public character As New Playercharacter

    Dim mainmenu As New menus(Me)


    'consumables
    Dim Bomb As New PictureBox
    Dim explosion As New PictureBox
    Dim bombcrate As New PictureBox
    Dim fire As New PictureBox
    Dim coin As New PictureBox
    Dim heart As New PictureBox
    'Enemies
    Public enemywah As weakenemy

    'Items
    Public Iteminventory As Items





    'queues
    Dim rightshotq As Queue(Of PictureBox) = New Queue(Of PictureBox)
    Dim leftshotq As Queue(Of PictureBox) = New Queue(Of PictureBox)
    Dim upshotq As Queue(Of PictureBox) = New Queue(Of PictureBox)
    Dim downshotq As Queue(Of PictureBox) = New Queue(Of PictureBox)

    Dim wahenemyspawnsq As Queue(Of weakenemy) = New Queue(Of weakenemy)

    Public playerX As Integer
    Public playerY As Integer

    Dim connection As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source = https://github.com/LougeLooj/Stave-Danger-Online-Data/blob/master/Stave%20Danger%20Leaderboards.accdb")


    Public Sub Startgame()
        mainmenu.Dispose()

        mainmenu.Location = New Point(-1000, -1000)
        playerspawn()

        Iteminventory.Uke = True
        PositionEnemies(Me)

    End Sub


    Public Sub ukespawn()


        Iteminventory.UkePicbox = New PictureBox
        Iteminventory.UkePicbox.Image = My.Resources.Ukelele_icon
        Iteminventory.UkePicbox.Location = New Point(400, 400)
        Iteminventory.UkePicbox.Height = 50
        Iteminventory.UkePicbox.Width = 70
        Iteminventory.UkePicbox.SizeMode = PictureBoxSizeMode.StretchImage
        Iteminventory.UkePicbox.Visible = True
        Iteminventory.UkePicbox.BringToFront()
        Me.Controls.Add(Iteminventory.UkePicbox)
        Itemtrackertmr.Start()

    End Sub

    Public Sub dubcannonspawn()


        Iteminventory.dubpicbox = New PictureBox
        Iteminventory.dubpicbox.Image = My.Resources.DUBGUN
        Iteminventory.dubpicbox.Location = New Point(400, 400)
        Iteminventory.dubpicbox.Height = 70
        Iteminventory.dubpicbox.Width = 120
        Iteminventory.dubpicbox.SizeMode = PictureBoxSizeMode.StretchImage
        Iteminventory.dubpicbox.Visible = True
        Iteminventory.dubpicbox.BringToFront()
        Me.Controls.Add(Iteminventory.dubpicbox)
        Itemtrackertmr.Start()
    End Sub

    Public Sub LPspawn()
        Iteminventory.LPPicbox = New PictureBox
        Iteminventory.LPPicbox.Image = My.Resources.les_paul
        Iteminventory.LPPicbox.Location = New Point(400, 400)
        Iteminventory.LPPicbox.Height = 120
        Iteminventory.LPPicbox.Width = 70
        Iteminventory.LPPicbox.SizeMode = PictureBoxSizeMode.StretchImage
        Iteminventory.LPPicbox.Visible = True
        Iteminventory.LPPicbox.BringToFront()
        Me.Controls.Add(Iteminventory.LPPicbox)
        Itemtrackertmr.Start()
    End Sub

    Public Sub playerspawn()
        If character.choice = 1 Then
            Playercontrolpicbox.Image = My.Resources.Untitled_2

        ElseIf character.choice = 2 Then
            Playercontrolpicbox.Image = My.Resources.wahhhh


        End If

    End Sub

    Public Sub bombcratespawn()
        Dim random As New Random
        Dim newTop As Integer = random.Next(Me.Height - bombcrate.Height)
        Dim newLeft As Integer = random.Next(Me.Width - bombcrate.Width)


        bombcrate = New PictureBox

        bombcrate.Top = newTop
        bombcrate.Left = newLeft
        bombcrate.Size = New Size(50, 50)
        bombcrate.BackColor = Color.Transparent
        bombcrate.Image = My.Resources.big_bomb_crate
        bombcrate.SizeMode = PictureBoxSizeMode.StretchImage
        bombcrate.Tag = "bombBox"
        bombcrate.BringToFront()
        Controls.Add(bombcrate)
        bombcrate.Show()

    End Sub

    Public Sub PositionEnemies(ByVal f As Form)
        enemywah = New weakenemy
        Dim randomwah As New Random
        Dim newTopwah As Integer = randomwah.Next(Me.Height - bombcrate.Height)
        Dim newLeftwah As Integer = randomwah.Next(Me.Width - bombcrate.Width)
        enemywah.picbox = New PictureBox
        enemywah.alive = True
        enemywah.picbox.Image = My.Resources.wahhhh
        enemywah.picbox.Location = New Point(newLeftwah, newTopwah)
        enemywah.picbox.Height = 120
        enemywah.picbox.Width = 70
        enemywah.picbox.SizeMode = PictureBoxSizeMode.StretchImage
        enemywah.picbox.Visible = True
        enemywah.picbox.Tag = "mob"
        enemywah.picbox.BringToFront()
        f.Controls.Add(enemywah.picbox)
        wahenemyspawnsq.Enqueue(enemywah)
        enemywah.healthbar = New PictureBox
        enemywah.healthbar.BackColor = Color.Red
        enemywah.healthbar.Height = 10
        enemywah.healthbar.Width = 100
        enemywah.healthbar.Visible = True
        enemywah.healthbar.BringToFront()
        f.Controls.Add(enemywah.healthbar)


    End Sub

    Public Sub downfireshoot()

        If Iteminventory.dub = True Then
            Dim dubwave As New PictureBox
            Dim rnote As Integer = CInt(Int((3 * Rnd()) + 1))
            dubwave.Height = 50
            dubwave.Width = 50
            dubwave.Location = New Point(Playercontrolpicbox.Location.X + 20, Playercontrolpicbox.Location.Y + 40)
            If rnote = 1 Then
                dubwave.BackColor = Color.Purple
            ElseIf rnote = 2 Then
                dubwave.BackColor = Color.Blue

            Else
                dubwave.BackColor = Color.Green

            End If
            dubwave.BringToFront()
            Controls.Add(dubwave)
            downshotq.Enqueue(dubwave)
            dubwave.Tag = "bullet"
        Else
            fire = New PictureBox
            Dim rnote As Integer = CInt(Int((3 * Rnd()) + 1))
            fire.Size = New Size(50, 50)
            fire.Location = New Point(Playercontrolpicbox.Location.X, Playercontrolpicbox.Location.Y + 50)
            fire.BackColor = Color.Transparent
            If rnote = 1 Then
                fire.Image = My.Resources.note_1314939_960_720
            ElseIf rnote = 2 Then
                fire.Image = My.Resources.music_1967480_960_720
            Else
                fire.Image = My.Resources.main_qimg_ad0535f4d4b642b6f5d40c7b20aa61f9
            End If
            fire.SizeMode = PictureBoxSizeMode.StretchImage
            fire.Tag = "bullet"
            fire.BringToFront()
            Controls.Add(fire)
            downshotq.Enqueue(fire)
        End If

    End Sub
    Public Sub leftfireshoot()

        If Iteminventory.dub = True Then
            Dim dubwave As New PictureBox
            Dim rnote As Integer = CInt(Int((3 * Rnd()) + 1))
            dubwave.Height = 50
            dubwave.Width = 50
            dubwave.Location = New Point(Playercontrolpicbox.Location.X, Playercontrolpicbox.Location.Y + 40)
            If rnote = 1 Then
                dubwave.BackColor = Color.Purple
            ElseIf rnote = 2 Then
                dubwave.BackColor = Color.Blue

            Else
                dubwave.BackColor = Color.Green

            End If
            Controls.Add(dubwave)
            leftshotq.Enqueue(dubwave)
            dubwave.Tag = "bullet"
        Else
            fire = New PictureBox

            Dim rnote As Integer = CInt(Int((3 * Rnd()) + 1))
            fire.Size = New Size(50, 50)
            fire.Location = New Point(Playercontrolpicbox.Location.X, Playercontrolpicbox.Location.Y + 50)
            fire.BackColor = Color.Transparent
            If rnote = 1 Then
                fire.Image = My.Resources.main_qimg_ad0535f4d4b642b6f5d40c7b20aa61f9
            ElseIf rnote = 2 Then
                fire.Image = My.Resources.note_1314939_960_720

            Else
                fire.Image = My.Resources.music_1967480_960_720

            End If
            fire.SizeMode = PictureBoxSizeMode.StretchImage
            fire.Tag = "bullet"
            Controls.Add(fire)
            leftshotq.Enqueue(fire)
            fire.BringToFront()

        End If



    End Sub
    Public Sub rightfireshoot()

        If Iteminventory.dub = True Then
            Dim dubwave As New PictureBox
            Dim rnote As Integer = CInt(Int((3 * Rnd()) + 1))
            dubwave.Height = 50
            dubwave.Width = 50
            dubwave.Location = New Point(Playercontrolpicbox.Location.X, Playercontrolpicbox.Location.Y + 40)
            If rnote = 1 Then
                dubwave.BackColor = Color.Purple
            ElseIf rnote = 2 Then
                dubwave.BackColor = Color.Blue

            Else
                dubwave.BackColor = Color.Green

            End If
            dubwave.BringToFront()
            Controls.Add(dubwave)
            rightshotq.Enqueue(dubwave)
            dubwave.Tag = "bullet"
        Else

            fire = New PictureBox

            Dim rnote As Integer = CInt(Int((3 * Rnd()) + 1))
            fire.Size = New Size(50, 50)
            fire.Location = New Point(Playercontrolpicbox.Location.X, Playercontrolpicbox.Location.Y + 50)
            fire.BackColor = Color.Transparent
            If rnote = 1 Then
                fire.Image = My.Resources.main_qimg_ad0535f4d4b642b6f5d40c7b20aa61f9
            ElseIf rnote = 2 Then
                fire.Image = My.Resources.note_1314939_960_720

            Else
                fire.Image = My.Resources.music_1967480_960_720

            End If
            fire.SizeMode = PictureBoxSizeMode.StretchImage
            fire.Tag = "bullet"
            Controls.Add(fire)
            rightshotq.Enqueue(fire)
            fire.BringToFront()

        End If
    End Sub
    Public Sub upfireshoot()

        If Iteminventory.dub = True Then
            Dim dubwave As New PictureBox
            Dim rnote As Integer = CInt(Int((3 * Rnd()) + 1))

            dubwave.Height = 50
            dubwave.Width = 50
            dubwave.Location = New Point(Playercontrolpicbox.Location.X + 20, Playercontrolpicbox.Location.Y + 40)
            If rnote = 1 Then
                dubwave.BackColor = Color.Purple
            ElseIf rnote = 2 Then
                dubwave.BackColor = Color.Blue

            Else
                dubwave.BackColor = Color.Green

            End If

            dubwave.BringToFront()
            Controls.Add(dubwave)
            upshotq.Enqueue(dubwave)
            dubwave.Tag = "bullet"
        Else

            fire = New PictureBox

            Dim rnote As Integer = CInt(Int((3 * Rnd()) + 1))
            fire.Size = New Size(50, 50)
            fire.Location = New Point(Playercontrolpicbox.Location.X, Playercontrolpicbox.Location.Y + 50)
            fire.BackColor = Color.Transparent
            If rnote = 1 Then
                fire.Image = My.Resources.main_qimg_ad0535f4d4b642b6f5d40c7b20aa61f9
            ElseIf rnote = 2 Then
                fire.Image = My.Resources.note_1314939_960_720

            Else
                fire.Image = My.Resources.music_1967480_960_720

            End If
            fire.SizeMode = PictureBoxSizeMode.StretchImage
            fire.Tag = "bullet"

            Controls.Add(fire)
            upshotq.Enqueue(fire)
            fire.BringToFront()
        End If

    End Sub
    Public Sub coinspawn()


        Dim random As New Random
        coin = New PictureBox
        Dim newTop As Integer = random.Next(Me.Height - bombcrate.Height)
        Dim newleft As Integer = random.Next(Me.Width - bombcrate.Width)


        coin.Size = New Size(25, 50)

        coin.BackColor = Color.Transparent
        coin.Image = My.Resources.coineh
        coin.SizeMode = PictureBoxSizeMode.StretchImage
        coin.Tag = "Coin"
        coin.Location = New Point(newleft, newTop)
        Controls.Add(coin)
        coin.BringToFront()

    End Sub
    Public Sub lifespawn()
        Dim random As New Random
        heart = New PictureBox
        Dim newTop As Integer = random.Next(Me.Height - bombcrate.Height)
        Dim newleft As Integer = random.Next(Me.Width - bombcrate.Width)


        heart.Size = New Size(25, 25)

        heart.BackColor = Color.Transparent
        heart.Image = My.Resources.heart
        heart.SizeMode = PictureBoxSizeMode.StretchImage
        heart.Tag = "heart"
        heart.Location = New Point(newleft, newTop)
        Controls.Add(heart)
        heart.BringToFront()
    End Sub

    Public Sub bombdrop()
        If bombs > 0 And BombTimer.Enabled = False Then
            bombs = bombs - 1

            Controls.Add(Bomb)

            Bomb.Location = New Point(Playercontrolpicbox.Location.X, Playercontrolpicbox.Location.Y)
            Bomb.Size = New Size(50, 50)
            Bomb.BackColor = Color.Transparent
            Bomb.ImageLocation = "\\solihullsfc.ac.uk\student\S2017\S172458\PROJECTS\big_bomb.png"
            Bomb.SizeMode = PictureBoxSizeMode.StretchImage
            Bomb.BringToFront()
            Controls.Add(Bomb)

            BombTimer.Enabled = True

        End If

    End Sub




    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown



        If e.KeyCode = Keys.Right Then


            Firerateright.Enabled = True
            Firerateup.Enabled = False
            Firerateleft.Enabled = False
            Fireratedown.Enabled = False

        ElseIf e.KeyCode = Keys.Left Then


            Firerateleft.Enabled = True
            Firerateup.Enabled = False
            Firerateright.Enabled = False
            Fireratedown.Enabled = False


        ElseIf e.KeyCode = Keys.Down Then

            Fireratedown.Enabled = True
            Firerateup.Enabled = False
            Firerateleft.Enabled = False
            Firerateright.Enabled = False


        ElseIf e.KeyCode = Keys.Up Then


            Firerateup.Enabled = True
            Firerateright.Enabled = False
            Firerateleft.Enabled = False
            Fireratedown.Enabled = False
        End If

        Select Case e.KeyCode

            Case Keys.D


                Timeright.Enabled = True

            Case Keys.A


                Timeleft.Enabled = True

            Case Keys.S


                Timedown.Enabled = True

            Case Keys.W

                Timeup.Enabled = True
            Case Keys.E
                bombdrop()

            Case Keys.B
                bombcratespawn()
            Case Keys.N

                PositionEnemies(Me)
                Me.Show()

            Case Keys.X
                LPspawn()
            Case Keys.M
                ukespawn()

            Case Keys.P
                DebugBox.Location = New Point(6, 81)





        End Select

    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timeright.Tick
        If Playercontrolpicbox.Left < 0 Then Playercontrolpicbox.Location = New Point(0, Playercontrolpicbox.Top)
        If Playercontrolpicbox.Top < 0 Then Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Left, 0)
        If (Playercontrolpicbox.Left + Playercontrolpicbox.Width) > Me.ClientSize.Width Then Playercontrolpicbox.Location = New Point(Me.ClientSize.Width - Playercontrolpicbox.Width, Playercontrolpicbox.Top)
        If (Playercontrolpicbox.Top + Playercontrolpicbox.Height) > Me.ClientSize.Height Then Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Left, Me.ClientSize.Height - Playercontrolpicbox.Height)

        Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Location.X + playerspeed, Playercontrolpicbox.Location.Y)





    End Sub



    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timeleft.Tick
        If Playercontrolpicbox.Left < 0 Then Playercontrolpicbox.Location = New Point(0, Playercontrolpicbox.Top)
        If Playercontrolpicbox.Top < 0 Then Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Left, 0)
        If (Playercontrolpicbox.Left + Playercontrolpicbox.Width) > Me.ClientSize.Width Then Playercontrolpicbox.Location = New Point(Me.ClientSize.Width - Playercontrolpicbox.Width, Playercontrolpicbox.Top)
        If (Playercontrolpicbox.Top + Playercontrolpicbox.Height) > Me.ClientSize.Height Then Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Left, Me.ClientSize.Height - Playercontrolpicbox.Height)
        Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Location.X - playerspeed, Playercontrolpicbox.Location.Y)


    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timedown.Tick

        If Playercontrolpicbox.Left < 0 Then Playercontrolpicbox.Location = New Point(0, Playercontrolpicbox.Top)
        If Playercontrolpicbox.Top < 0 Then Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Left, 0)
        If (Playercontrolpicbox.Left + Playercontrolpicbox.Width) > Me.ClientSize.Width Then Playercontrolpicbox.Location = New Point(Me.ClientSize.Width - Playercontrolpicbox.Width, Playercontrolpicbox.Top)
        If (Playercontrolpicbox.Top + Playercontrolpicbox.Height) > Me.ClientSize.Height Then Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Left, Me.ClientSize.Height - Playercontrolpicbox.Height)
        Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Location.X, Playercontrolpicbox.Location.Y + playerspeed)



    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timeup.Tick


        If Playercontrolpicbox.Left < 0 Then Playercontrolpicbox.Location = New Point(0, Playercontrolpicbox.Top)
        If Playercontrolpicbox.Top < 0 Then Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Left, 0)
        If (Playercontrolpicbox.Left + Playercontrolpicbox.Width) > Me.ClientSize.Width Then Playercontrolpicbox.Location = New Point(Me.ClientSize.Width - Playercontrolpicbox.Width, Playercontrolpicbox.Top)
        If (Playercontrolpicbox.Top + Playercontrolpicbox.Height) > Me.ClientSize.Height Then Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Left, Me.ClientSize.Height - Playercontrolpicbox.Height)


        Playercontrolpicbox.Location = New Point(Playercontrolpicbox.Location.X, Playercontrolpicbox.Location.Y - playerspeed)




    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        Select Case e.KeyCode


            Case Keys.D


                Timeright.Enabled = False

            Case Keys.A


                Timeleft.Enabled = False

            Case Keys.S


                Timedown.Enabled = False

            Case Keys.W

                Timeup.Enabled = False

            Case Keys.Right


                Firerateright.Enabled = False




            Case Keys.Left

                Firerateleft.Enabled = False


            Case Keys.Down


                Fireratedown.Enabled = False



            Case Keys.Up



                Firerateup.Enabled = False

            Case Keys.P
                DebugBox.Location = New Point(-1000, 1000)



        End Select
    End Sub

    Private Sub Bombtimer_Tick(sender As Object, e As EventArgs) Handles BombTimer.Tick
        If BombTimer.Interval = 2000 Then
            explosion.Location = New Point(Bomb.Location.X - 130, Bomb.Location.Y - 120)
            explosion.Size = New Size(300, 300)
            explosion.BackColor = Color.Transparent
            explosion.Image = My.Resources.explosion
            explosion.SizeMode = PictureBoxSizeMode.StretchImage


            Controls.Add(explosion)
            If Playercontrolpicbox.Bounds.IntersectsWith(explosion.Bounds) Then
                character.Luigihp = character.Luigihp - 10
            End If

            Explodetimer.Enabled = True
            Me.Controls.Remove(Bomb)
            BombTimer.Enabled = False


        End If
    End Sub

    Private Sub Playercontrolpicbox_Click(sender As Object, e As EventArgs) Handles Playercontrolpicbox.Click

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub



    Private Sub collisiondet_Tick(sender As Object, e As EventArgs) Handles Collisiondet.Tick
        Bombcounter.Text = "Bombs: " & bombs
        Coincounter.Text = "Coins: " & coins

        Fireratedown.Interval = firerate
        Firerateleft.Interval = firerate
        Firerateright.Interval = firerate
        Firerateup.Interval = firerate

        If Iteminventory.uke = True Then

            currentitem.Image = My.Resources.Ukelele_icon


        ElseIf Iteminventory.dub = True Then

            currentitem.Image = My.Resources.DUBGUN

        ElseIf Iteminventory.LP = True Then
            currentitem.Image = My.Resources.les_paul

        End If

    End Sub

    Private Sub BombCrate_Disposed(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Enemytime_Tick(sender As Object, e As EventArgs) Handles checktmr.Tick
        For Each picturebox In Me.Controls

            If picturebox.tag = "ColTop" And Playercontrolpicbox.Bounds.IntersectsWith(picturebox.bounds) Then




                Playercontrolpicbox.Top -= playerspeed








            End If
            If picturebox.tag = "ColBottom" And Playercontrolpicbox.Bounds.IntersectsWith(picturebox.bounds) Then




                Playercontrolpicbox.Top += playerspeed








            End If
            If picturebox.tag = "ColLeft" And Playercontrolpicbox.Bounds.IntersectsWith(picturebox.bounds) Then




                Playercontrolpicbox.Left -= playerspeed








            End If
            If picturebox.tag = "ColRight" And Playercontrolpicbox.Bounds.IntersectsWith(picturebox.bounds) Then




                Playercontrolpicbox.Left += playerspeed








            End If


        Next

        For Each PictureBox In Me.Controls
            If bombs < 99 And PictureBox.tag = "bombBox" And Playercontrolpicbox.Bounds.IntersectsWith(PictureBox.Bounds) Then

                PictureBox.Hide()
                PictureBox.Location = New Point(Me.Width, Me.Height)

                bombs = bombs + 1
            End If

        Next
        For Each PictureBox In Me.Controls
            If coins < 99 And PictureBox.tag = "coin" And Playercontrolpicbox.Bounds.IntersectsWith(PictureBox.Bounds) Then

                PictureBox.Hide()
                PictureBox.Location = New Point(Me.Width, Me.Height)

                coins = coins + 1
            End If

        Next
        For Each PictureBox In Me.Controls
            If character.Luigihp < 100 And PictureBox.tag = "heart" And Playercontrolpicbox.Bounds.IntersectsWith(PictureBox.Bounds) Then

                PictureBox.Hide()
                PictureBox.Location = New Point(Me.Width, Me.Height)

                character.Luigihp = character.Luigihp + 10
            End If

        Next
        For Each PictureBox In Me.Controls
            If (PictureBox.tag = "brick" Or PictureBox.tag = "ColTop" Or PictureBox.tag = "ColBottom" Or PictureBox.tag = "ColLeft" Or PictureBox.tag = "ColRight") And explosion.Bounds.IntersectsWith(PictureBox.Bounds) Then

                PictureBox.Hide()

                PictureBox.Location = New Point(Me.Width, Me.Height)
            End If
        Next




        Healthbar.Width = character.Luigihp
        If character.Luigihp < 0.5 * character.MaxHealth And character.Luigihp > 0.25 * character.MaxHealth Then
            Healthbar.BackColor = Color.Yellow
        ElseIf character.Luigihp < 0.25 * character.MaxHealth Then
            Healthbar.BackColor = Color.Red
        End If

        If character.Luigihp <= 0 Then

            Me.Dispose()






        End If


    End Sub

    Private Sub explodetimer_Tick(sender As Object, e As EventArgs) Handles Explodetimer.Tick
        If Explodetimer.Interval = 1000 Then


            Me.Controls.Remove(explosion)
            explosion.Location = New Point(Me.Width, Me.Height)



        End If

    End Sub

    Private Sub timercollision_Tick(sender As Object, e As EventArgs)



    End Sub

    Private Sub shootup_Tick(sender As Object, e As EventArgs) Handles Shootup.Tick
        For Each element As PictureBox In upshotq

            element.Top -= shotspeed

            If element.Left < 0 Then element.Dispose()

            If element.Top < 0 Then element.Dispose()

            If element.Left > 800 Then element.Dispose()

            If element.Top > 800 Then element.Dispose()

        Next
    End Sub

    Private Sub shootdown_Tick(sender As Object, e As EventArgs) Handles shootdown.Tick
        For Each element As PictureBox In downshotq

            element.Top += shotspeed

            If element.Left < 0 Then
                element.Dispose()
            End If

            If element.Top < 0 Then element.Dispose()

            If element.Left > 800 Then

                element.Dispose()
            End If

            If element.Top > 800 Then

                element.Dispose()

            End If

        Next
    End Sub

    Private Sub shootleft_Tick(sender As Object, e As EventArgs) Handles shootleft.Tick
        For Each element As PictureBox In leftshotq

            element.Left -= shotspeed

            If element.Left < 0 Then
                element.Dispose()

            End If



            If element.Top < 0 Then
                element.Dispose()

            End If

            If element.Left > 800 Then
                element.Dispose()
            End If

            If element.Top > 800 Then
                element.Dispose()
            End If

        Next
    End Sub

    Private Sub shootright_Tick(sender As Object, e As EventArgs) Handles shootright.Tick
        For Each element As PictureBox In rightshotq

            element.Left += shotspeed

            If element.Left < 0 Then element.Dispose()

            If element.Top < 0 Then element.Dispose()

            If element.Left > 800 Then element.Dispose()

            If element.Top > 800 Then element.Dispose()

        Next
    End Sub

    Private Sub firerateright_Tick(sender As Object, e As EventArgs) Handles Firerateright.Tick

        rightfireshoot()

    End Sub

    Private Sub firerateleft_Tick(sender As Object, e As EventArgs) Handles Firerateleft.Tick

        leftfireshoot()

    End Sub

    Private Sub fireratedown_Tick(sender As Object, e As EventArgs) Handles Fireratedown.Tick

        downfireshoot()

    End Sub

    Private Sub firerateup_Tick(sender As Object, e As EventArgs) Handles Firerateup.Tick

        upfireshoot()

    End Sub

    Private Sub enemy_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub enemyai_Tick(sender As Object, e As EventArgs) Handles WaluigiAI.Tick
        playerX = Playercontrolpicbox.Location.X
        playerY = Playercontrolpicbox.Location.Y

        For Each picturebox In Me.Controls
            If picturebox.tag = "mob" Then
                Dim EnemyWahX As Integer = picturebox.Location.X
                Dim EnemyWahY As Integer = picturebox.Location.Y

                If EnemyWahX > playerX Then
                    EnemyWahX = EnemyWahX - enemywah.speed
                    picturebox.Location = New Point(EnemyWahX, EnemyWahY)
                Else
                    EnemyWahX = EnemyWahX + enemywah.speed
                    picturebox.Location = New Point(EnemyWahX, EnemyWahY)
                End If


                If EnemyWahY > playerY Then
                    EnemyWahY = EnemyWahY - enemywah.speed
                    picturebox.Location = New Point(EnemyWahX, EnemyWahY)
                Else
                    EnemyWahY = EnemyWahY + enemywah.speed
                    picturebox.Location = New Point(EnemyWahX, EnemyWahY)
                End If
            End If
        Next
    End Sub

    Private Sub WalAI2_Tick(sender As Object, e As EventArgs) Handles WalAI2.Tick
        For Each element As weakenemy In wahenemyspawnsq
            If element.weakenemyhp <= 0 Then
                element.alive = False
                element.picbox.Dispose()

                element.picbox.Location = New Point(Me.Width, Me.Height)



            End If
        Next

        For Each element As weakenemy In wahenemyspawnsq
            For Each picturebox In Me.Controls
                If picturebox.tag = "bullet" And picturebox.bounds.intersectswith(element.picbox.Bounds) Then
                    picturebox.location = New Point(Me.Width, Me.Height)

                    element.weakenemyhp = element.weakenemyhp - damage






                End If

            Next
            If element.picbox.Bounds.IntersectsWith(explosion.Bounds) Then
                element.weakenemyhp = element.weakenemyhp - bombdamage
            End If
        Next

        For Each element As weakenemy In wahenemyspawnsq
            element.healthbar.Width = element.weakenemyhp
            element.healthbar.Location = New Point(element.picbox.Left - 15, element.picbox.Top - 10)
        Next





    End Sub



    Private Sub Timer1_Tick_1(sender As Object, e As EventArgs) Handles Timer1.Tick
        For Each picturebox In Me.Controls
            If picturebox.tag = "mob" And picturebox.bounds.intersectswith(Playercontrolpicbox.Bounds) Then
                If character.Luigihp > 0 Then
                    character.Luigihp = character.Luigihp - 10
                End If
            End If
        Next


    End Sub

    Private Sub Itemtrackertmr_Tick(sender As Object, e As EventArgs) Handles Itemtrackertmr.Tick




        If Playercontrolpicbox.Bounds.IntersectsWith(Iteminventory.dubpicbox.Bounds) And GunPickupCooldownTmr.Enabled = False Then
            firerate = 50
            damage = 20

            damage = damage + ExtraDamage
            firerate = firerate + ExtraFirerate

            Iteminventory.dub = True
            ItemNamelbl.Text = "Dubstep Cannon"
            ItemDescriptionlbl.Text = "Classy"
            ItemNamelbl.Visible = True
            ItemDescriptionlbl.Visible = True
            Nametagtmr.Start()

            If Iteminventory.uke = True Then


                Iteminventory.uke = False


                GunPickupCooldownTmr.Start()
                ukespawn()


                Iteminventory.UkePicbox.Location = New Point(Playercontrolpicbox.Left, Playercontrolpicbox.Top)

            End If
            Iteminventory.dubpicbox.Dispose()
            Iteminventory.dubpicbox .location = New Point(-1000, 1000)

            If Iteminventory.LP = True Then

                Iteminventory.LP = False
                GunPickupCooldownTmr.Start()
                LPspawn()
                Iteminventory.LPPicbox.Location = New Point(Playercontrolpicbox.Left, Playercontrolpicbox.Top)

            End If





        End If









        If Playercontrolpicbox.Bounds.IntersectsWith(Iteminventory.UkePicbox.Bounds) And GunPickupCooldownTmr.Enabled = False Then
            firerate = 300
            damage = 50

            damage = damage + ExtraDamage
            firerate = firerate + ExtraFirerate
            Iteminventory.Uke = True
            ItemNamelbl.Text = "The Ukulele"
            ItemDescriptionlbl.Text = "Everyone has to start somewhere"
            ItemNamelbl.Visible = True
            ItemDescriptionlbl.Visible = True

            Nametagtmr.Start()

            If Iteminventory.Dub = True Then

                Iteminventory.Dub = False


                GunPickupCooldownTmr.Start()
                dubcannonspawn()
                Iteminventory.DubPicbox.Location = New Point(Playercontrolpicbox.Left, Playercontrolpicbox.Top)


            End If

            If Iteminventory.LP = True Then
                Iteminventory.LP = False
                GunPickupCooldownTmr.Start()
                LPspawn()
                Iteminventory.LPPicbox.Location = New Point(Playercontrolpicbox.Left, Playercontrolpicbox.Top)

            End If
            Iteminventory.UkePicbox.Dispose()
            Iteminventory.UkePicbox.Location = New Point(-1000, 1000)



        End If
        If Playercontrolpicbox.Bounds.IntersectsWith(Iteminventory.LPPicbox.Bounds) And GunPickupCooldownTmr.Enabled = False Then
            firerate = 200
            damage = 75

            damage = damage + ExtraDamage
            firerate = firerate + ExtraFirerate
            Iteminventory.LP = True
            ItemNamelbl.Text = "The Les Paul"
            ItemDescriptionlbl.Text = "The most classic, the most legendary, the... best? "
            ItemNamelbl.Visible = True
            ItemDescriptionlbl.Visible = True

            Nametagtmr.Start()


            If Iteminventory.Dub = True Then

                Iteminventory.Dub = False


                GunPickupCooldownTmr.Start()
                dubcannonspawn()
                Iteminventory.DubPicbox.Location = New Point(Playercontrolpicbox.Left, Playercontrolpicbox.Top)


            End If

            If Iteminventory.Uke = True Then


                Iteminventory.Uke = False


                GunPickupCooldownTmr.Start()
                ukespawn()


                Iteminventory.UkePicbox.Location = New Point(Playercontrolpicbox.Left, Playercontrolpicbox.Top)

            End If
            Iteminventory.LPPicbox.Dispose()
            Iteminventory.LPPicbox.Location = New Point(-1000, 1000)



        End If

        If Iteminventory.uke = True Then
            ukecheck.Text = "ItemUke:true"

        Else ukecheck.Text = "Itemuke: false"

        End If

        If Iteminventory.dub = True Then
            dubcheck.Text = "Itemdub: true"

        Else dubcheck.Text = "Itemdub:false"

        End If

    End Sub





    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs)

    End Sub



    Private Sub GameForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Iteminventory = New Items
        Iteminventory.UkePicbox = New PictureBox
        Iteminventory.LPPicbox = New PictureBox
        Iteminventory.DubPicbox = New PictureBox
        Controls.Add(mainmenu)
        mainmenu.Top = 0
        mainmenu.Left = 0
        mainmenu.BringToFront()



    End Sub


    Private Sub GroupBox1_Enter_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub GunPickupCooldownTmr_Tick(sender As Object, e As EventArgs) Handles GunPickupCooldownTmr.Tick
        If GunPickupCooldownTmr.Interval = 2000 Then
            GunPickupCooldownTmr.Stop()


        End If
    End Sub

    Private Sub Nametagtmr_Tick(sender As Object, e As EventArgs) Handles Nametagtmr.Tick
        If Nametagtmr.Interval = 1500 Then
            ItemNamelbl.Visible = False
            ItemDescriptionlbl.Visible = False

            Nametagtmr.Stop()
        End If
    End Sub

    Private Sub ItemNamelbl_Click(sender As Object, e As EventArgs) Handles ItemNamelbl.Click

    End Sub
End Class

